# Getting Started

To get started please follow the instructions below.

1. rename xdevDependencies to devDependencies
2. run npm i
3. run npx msw init public
4. OPTIONAL uncomment service worker code in index.tsx
